#bị lỗi canvas thì: npm i canvas@2.7.0 , npm i sqlite3
.
