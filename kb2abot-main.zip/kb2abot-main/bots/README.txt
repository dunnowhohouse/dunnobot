﻿ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA


1. Chỗ này để đặt các file export được từ tiện ích j2team cookie
2. Chỉ cần export cookie từ facebook.com là được rồi!
3. Bạn có thể rename theo cách bạn thích!


ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA