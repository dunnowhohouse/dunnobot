﻿ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA


1. Chỗ này để lưu trữ data của kb2abot
2. Tên của datastore được đặt theo UID của bạn xài để login
3. Không được đổi tên của các file này!


ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA