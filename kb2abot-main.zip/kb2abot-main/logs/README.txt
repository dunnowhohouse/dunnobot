﻿ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA


1. Chỗ này để lưu trữ các log trong quá trình deploy (bị lỗi và ko bị lỗi đều có)
2. Tên file được đặt theo giờ nên các bạn sort theo "Date modified" hay "Name" đều được nhé!


ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA