# Author : Khoa Ko Mlem
# Copyright (c) khoakomlem
# Script chạy update
echo "Dang chay update . . ."
npm run update
read -p "Nhan phim ENTER de thoat . . ."
