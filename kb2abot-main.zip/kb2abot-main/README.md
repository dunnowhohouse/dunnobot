<h1 align="center">
	<a href="#"><img src="https://i.imgur.com/nwkPWAT.png" alt="Kb2abot"></a>
</h1>
<p align="center">
	<img alt="size" src="https://img.shields.io/github/repo-size/kb2abot/kb2abot.svg?style=flat-square&label=size">
	<img alt="code-version" src="https://img.shields.io/badge/dynamic/json?color=red&label=code%20version&prefix=v&query=%24.version&url=https://raw.githubusercontent.com/kb2abot/kb2abot/main/package.json&style=flat-square">
	<a href="https://github.com/kb2abot/kb2abot/commits"><img alt="commits" src="https://img.shields.io/github/commit-activity/m/kb2abot/kb2abot.svg?label=commit&style=flat-square"></a>
	<img alt="downloads" src="https://img.shields.io/github/downloads/kb2ateam/kb2abot/latest/total?style=flat-square"></img>
</p>

#  GIỚI THIỆU
Đây đơn giản là một con bot tự động trả lời các tin nhắn và có thể sử dụng nhiều lệnh hay khác!
#  HƯỚNG DẪN CÀI ĐẶT
Bạn xem kĩ tại trang: https://kb2ateam.github.io/kb2abot-docs/ <br>
Sau khi cài đặt xong, lúc này bot vẫn chưa có nhiều plugin nên các bạn vào trang http://bit.ly/kb2abot tìm tải các plugin mà bạn muốn về folder /main/deploy/plugins nhé!
# CẢM ƠN CÁC BẠN ĐÃ SỬ DỤNG KB2ABOT 
Total income (donating): 360,000 vnđ 🔥<br>
Cảm ơn mọi người rất nhiều!
